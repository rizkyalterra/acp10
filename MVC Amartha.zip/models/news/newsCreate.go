package news

type NewsCreate struct {
	Title   string `json:"title"`
	Content string `json:"content"`
}
