package news

import (
	"amartha/models/base"
)

type NewsResponse struct {
	base.BaseResponse
	Data []News `json:"data"`
}
