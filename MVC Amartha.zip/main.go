package main

import (
	"amartha/configs"
	"amartha/routes"
)

func main() {
	configs.InitDB()
	e := routes.New()
	e.Start(":8000")
}
