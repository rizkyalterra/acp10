package routes

import (
	"amartha/controllers"

	"github.com/labstack/echo/v4"
)

func New() *echo.Echo {
	e := echo.New()

	e.GET("/news", controllers.GetNewsControllers)
	e.POST("/news", controllers.CreateNewsControllers)
	e.GET("/news/:newsId", controllers.DetailNewsControllers)

	e.POST("/login", controllers.LoginController)

	return e
}
